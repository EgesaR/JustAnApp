import React, { useState } from "react"
import {
  Text,
  View
} from "react-native"

const GroupsScreen = () => {
  return(
    <View>
    <Text>GroupsScreen</Text>
    </View>
    )
}

export default GroupsScreen