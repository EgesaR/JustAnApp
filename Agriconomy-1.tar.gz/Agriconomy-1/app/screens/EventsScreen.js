import React, { useState } from "react"
import {
  Text,
  View
} from "react-native"

const EventsScreen = () => {
  return(
    <View>
    <Text>EventsScreen</Text>
    </View>
    )
}

export default EventsScreen