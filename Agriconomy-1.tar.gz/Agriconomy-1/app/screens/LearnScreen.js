import React, { useState } from "react"
import {
  Text,
  View
} from "react-native"

const LearnScreen = () => {
  return(
    <View>
    <Text>LearnScreen</Text>
    </View>
    )
}

export default LearnScreen