const Courses = [
  {
    name: "Horiculture"
  },
  {
    name: "Animal Husbandry"
  },
  {
    name: "Crop Growing"
  },
]

export default Courses 
