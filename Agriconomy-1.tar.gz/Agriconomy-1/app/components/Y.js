const ListItems = [
  { 
    username: "Sarah",
    password: "12345678",
    groups: [ "The Alenges", "Magkis" ] 
  },
  { 
    username: "Dan", 
    password: "phonewat",
    groups: [ "The Alenges", "PlantDio" ]
  },
  { 
    username: "Walter",
    password: "password",
    groups: [ "The Alenges", "Magkis" ] 
  },
  { 
    username: "Fred",
    password: "code0987",
    groups: [ "The Alenges", "Magkis" ] 
  },
  { 
    username: "Alex", 
    password: "alex0981",
    groups: [ "The Alenges", "Jaslins" ]
  },
  { 
    username: "Kevin",
    passworded: "YouTube1",
    groups: [ "The IOP scientists", "Magkis" ] 
  },
  { 
    username: "Henry",
    password: "Fishqwer",
    groups: [ "The Open Arc", "Magkis" ] 
  }
]

export default ListItems
