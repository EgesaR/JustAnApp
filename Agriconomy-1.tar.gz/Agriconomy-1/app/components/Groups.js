const Groups = [
  {
    name: "Gongas",
    members: ["Fisher", "Henry", "John", "Mary"],
  },
  {
    name: "Evitable",
    members: ["Kevin", "Calvin", "Doe", "Sam", "Ray", "Levi", "Alex"]
  },
];

export default Groups;
