import React, { Component } from 'react';
import { StyleSheet, View, Image } from 'react-native';
import { SafeAreaView } from 'react-navigation';
import { mapping, light as lightTheme } from '@eva-design/eva';
import { EvaIconsPack } from '@ui-kitten/eva-icons';
import {
  ApplicationProvider,
  Avatar,
  BottomNavigation,
  BottomNavigationTab,
  Button,
  ButtonGroup,
  Calendar,
  CheckBox,
  Datepicker,
  Drawer,
  DrawerHeaderFooter,
  Icon,
  IconRegistry,
  Input,
  Layout,
  List,
  ListItem,
  Menu,
  Modal,
  NativeDateService,
  OverflowMenu,
  Popover,
  Radio,
  RadioGroup,
  RangeDatepicker,
  Select,
  Spinner,
  Tab,
  TabView,
  Text,
  Toggle,
  Tooltip,
  TopNavigation,
  TopNavigationAction,
} from 'react-native-ui-kitten';
import f from "fs"

const RootLayout = ({ style, children }) => (
  <View
    style={{
      flex: 1,
      alignSelf: 'stretch',
    }}>
    <IconRegistry icons={EvaIconsPack} />
    <ApplicationProvider mapping={mapping} theme={lightTheme}>
      <Layout
        style={[
          {
            flex: 1,
            width: '100%',
            paddingVertical: 8,
            paddingHorizontal: 16,
          },
          style,
        ]}>
        {children}
      </Layout>
    </ApplicationProvider>
  </View>
);

export class TabViewSimpleUsageShowcase extends Component {
  state = {
    selectedIndex: 0,
  };
  
  onSelect = (selectedIndex) => {
    this.setState({ selectedIndex });
  };

  render() {
    return (
      <RootLayout style={{overflow: "hidden"}}>
        <TabView selectedIndex={this.state.selectedIndex} onSelect={this.onSelect}>
          <Tab title="DASHBOARD">
            <Text style={{backgroundColor:"blue", width: "100%", marginLeft:15}}>DASHBOARD</Text>
          </Tab>
          <Tab title="SETTING">
            <Text>SETTINGS</Text>
          </Tab>
        </TabView>
      </RootLayout>
    );
  }
}